"""The two explicit cell types rule out any affine cardinality certificate
throughout [20202/65536,1/2). Python standard library, exact arithmetic."""
from functools import lru_cache
from math import comb
from fractions import Fraction as F

W=2**75
P=2**60
def ceil(a,b): return -(-a//b)
def slog(a,b):
    assert b<=a<=2*b
    L=W*(a-b)//(a+b)
    U=ceil(W*(a-b),a+b)
    L2=L*L//W
    U2=ceil(U*U,W)
    l=h=0
    for j in range(22):
        l+=2*L//(2*j+1)
        h+=ceil(2*U,2*j+1)
        L=L*L2//W
        U=ceil(U*U2,W)
    return l,h+ceil(2*U*W,45*(W-U2))

LN2=slog(2,1)
def lgn(a,b=1):
    k=a.bit_length()-b.bit_length()
    if (a<b<<k if k>=0 else a<<-k<b): k-=1
    aa=a if k>=0 else a<<-k
    bb=b if k<0 else b<<k
    l,h=slog(aa,bb)
    return l+k*LN2[k<0],h+k*LN2[k>=0]

@lru_cache(None)
def cup(a):
    return LN2[1]+ceil(a*lgn(a,P)[1]+(P-a)*lgn(P-a,P)[1],P)

def dlow(d,a):
    size=d+1
    D=P**d
    w=[a**r*(P-a)**(d-r) for r in range(d+1)]
    h=0
    for r in range(d+1):
        v=w[r]+(r*w[r-1] if r else 0)+((d-r)*w[r+1] if r<d else 0)
        u=comb(d,r)*v*lgn((1<<d)*v,D*size)[0]
        h+=u
    return h//(D*size)

@lru_cache(None)
def marginal_weighted_dlow(a):
    return 11*dlow(10,a)+25*dlow(9,a)

# p >= 2/5, p < 1/2: entropy subadditivity proves D >= rho² B/2.
# C <= rho²/2*[1+rho²/(6(1-rho²))].
assert (F(1,5))**2<F(1,23)
assert 11*F(810,121)+25*F(144,25)==216+F(18,11)
# The high-noise proof in fact starts here, just below 2/5:
lo=20202*(P//65536)
hi=2*P//5
assert (1-2*F(hi,P))**2<F(1,23)
stack=[(lo,hi)]
ct=0
while stack:
    a,b=stack.pop()
    # Divergences and C both decrease, in p, by the BSC noise semigroup.
    if marginal_weighted_dlow(b)>216*cup(a):
        ct+=1
    else:
        c=(a+b)//2
        assert a<c<b,(a,b)
        stack.extend(((a,c),(c,b)))
print('two-ball envelope obstruction verified on',F(lo,P),'<=p<1/2;',
      ct,'closed dyadic intervals and analytic high-noise cap')
