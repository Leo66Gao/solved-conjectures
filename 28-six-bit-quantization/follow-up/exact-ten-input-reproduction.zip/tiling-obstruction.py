"""Pure integer verification of the shell-projection LP dual certificates."""
import json
from collections import Counter
from itertools import combinations
from fractions import Fraction
from pathlib import Path

N=1<<10
U=list(range(N))
B=[1<<j for j in range(10)]
def ball(c):
    return [c]+[c^b for b in B]

# Keep the generator's indexing convention for its fixed tiles.
T=[(0,ball(c)) for c in U]
for b in B:
    for c in U:
        if not c&b:
            T.append((1,sorted(set(ball(c)+ball(c^b)))))
for bits in combinations(B,4):
    v=sum(bits)
    D=[x for x in U if x&v==x]
    for c in U:
        if not c&v:
            T.append((2,[c^x for x in D]))
assert len(T)==19584
entries=json.loads(Path(__file__).with_name('tiling-duals.json').read_text())
assert sorted(row[2] for row in entries)==sorted(['A']+[f'AB{d}' for d in [3,5,6,7,8,9]]+[f'AA{d}' for d in range(8,11)]+[f'BB{d}' for d in range(4,9)])
for fixed, masks, label, typ, scale, y in entries:
    assert scale>0 and typ in ('dual','farkas')
    if label=='A':
        assert fixed==[0] and masks==[1023]
    elif label[:2]=='AB':
        d=int(label[2:])
        b=(1<<(d+1))-2
        assert fixed==[0,1024+(b>>1)] and masks==[1,b,1023^1^b]
        assert T[fixed[1]]==(1,sorted(set(ball(b)+ball(b^1))))
    elif label[:2]=='AA':
        d=int(label[2:])
        b=(1<<d)-1
        assert fixed==[0,b] and masks==[b,1023^b]
        assert T[fixed[1]]==(0,ball(b))
        assert typ=='farkas'
    else:
        assert label[:2]=='BB'
        d=int(label[2:])
        b=(1<<(d+2))-4
        assert fixed==[1024,1536+(b>>1)] and masks==[1,2,b,1023^3^b]
        assert T[fixed[0]]==(1,sorted(set(ball(0)+ball(1))))
        assert T[fixed[1]]==(1,sorted(set(ball(b)+ball(b^2))))
        assert typ=='farkas'
    covered=set()
    fixed_counts=Counter()
    for k in fixed:
        t,S=T[k]
        assert covered.isdisjoint(S)
        covered.update(S)
        fixed_counts[t]+=1
    idx={}
    orb=[]
    for x in U:
        p=tuple((x&m).bit_count() for m in masks)
        orb.append(idx.setdefault(p,len(idx)))
    L=len(idx)
    assert len(y)==L+3
    for t,S in T:
        if covered.isdisjoint(S):
            assert y[L+t]+sum(y[orb[x]] for x in S)<=0,(label,t,S)
    assert -4*y[L]-5*y[L+1]+9*y[L+2]<=(-scale if typ=='dual' else 0)
    v=(sum(y[orb[x]] for x in U if x not in covered)
       -fixed_counts[0]*y[L]-fixed_counts[1]*y[L+1]
       +(64-fixed_counts[2])*y[L+2])
    if typ=='dual':
        lim=Fraction(-v,scale)
        assert lim<(6 if label=='A' else 5)
        print(label,'requires q <=',lim)
    else:
        assert v>0
        print(label,'infeasible, Farkas contradiction',Fraction(v,scale))
