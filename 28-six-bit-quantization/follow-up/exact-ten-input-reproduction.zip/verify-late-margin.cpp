// Exact integer certificate. Compile g++ -O3 -march=native -std=c++17 verify-ten-band.cpp -o verify-ten-band.
// Args: first cardinality, last cardinality, lower p numerator, upper p numerator,
//       denominator exponent (p grid denominator 2^exp), lambda numerator, lambda denominator.
#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <utility>
using u64=uint64_t;
using i64=int64_t;
using U=__uint128_t;
using I=__int128_t;
constexpr int n=10,N=1<<n,M=44,W=44,J=14,V=46;
constexpr u64 Q=1ULL<<W,L=1ULL<<V;
constexpr u64 D=1ULL<<27;
using Pair=std::pair<i64,i64>;
Pair ln2, logm[M+1];
i64 tabhi[(1<<J)+1];
u64 recip[(1<<J)+1];
int child[N][n],nc[N],pred[N],mmax,ni,nj;
u64 wl[n+1],K[N],G[N];
int upper_t[M+1],den_t[M+1];
i64 hmid_l,hmid_u,hlo_l,hhi_u;
u64 certified_in_interval;
u64 tried_intervals=0, evaluations=0,total_eval=0;
long long checked[M+1], accepted[M+1];
u64 completed[M+1];
int mincheck, maxcheck;
int word[M+1];
bool shape_all_ok[M+1];
I mn[M+1], req[M+1];
int hexp, num,den;
u64 ce(U a,u64 b){return (a+b-1)/b;}
Pair logsmall(u64 a,u64 b){
 assert(b<=a && a<=2*b);
 u64 zl=(U)L*(a-b)/(a+b),zh=ce((U)L*(a-b),a+b);
 u64 rl=(U)zl*zl>>V,rh=ce((U)zh*zh,L);u64 sl=0,sh=0;
 for(int j=0;j<18;j++){sl+=2*zl/(2*j+1);sh+=ce(2*zh,2*j+1);zl=(U)zl*rl>>V;zh=ce((U)zh*rh,L);}
 return {(i64)sl,(i64)(sh+ce((U)2*zh*L,37*(L-rh)))};
}
Pair logint(u64 a){
 int e=63-__builtin_clzll(a);auto p=logsmall(a,1ULL<<e);
 return {p.first+e*ln2.first,p.second+e*ln2.second};
}
Pair entropy(u64 a){
 if(a==0 || a==D)return{0,0};
 auto lb=logint(a),rb=logint(D-a);
 i64 lo=27*ln2.first-(((I)a*lb.second+(I)(D-a)*rb.second+D-1)>>27);
 i64 hi=27*ln2.second-(((I)a*lb.first+(I)(D-a)*rb.first)>>27);
 return {lo,hi};
}
// Upper-bound ln(g/Q), where 1<=g<Q, by the next mantissa table entry.
inline i64 negative_log_lower(u64 g){
 g=std::min(Q,g);
 if(g==Q)return 0;
 int e=63-__builtin_clzll(g);
 u64 j=(e>=J?g>>(e-J):g<<(J-e))-(1<<J);
#ifdef TANGENT
 i64 u=tabhi[j]; // tangent at the left mantissa boundary
 if(e>J){int k=e-J;u64 rem=g&((1ULL<<k)-1);u+=(rem*recip[j]+((1ULL<<k)-1))>>k;}
 i64 l=(W-e)*ln2.first-u;
#else
 i64 l=(W-e)*ln2.first-tabhi[j+1];
#endif
 return std::max((i64)0,l);
}
void setup_kernel(u64 a){
 // Products floor after each multiplication; true scaled kernel entries are in [wl,wl+n].
 for(int j=0;j<=n;j++){u64 z=Q;for(int i=0;i<n;i++)z=(z*(U)(i<j?a:D-a))>>27;wl[j]=z;}
 for(int x=0;x<N;x++)K[x]=wl[__builtin_popcount(x)];
}
bool critical(int m){
 if(m==16)return word[16]==15;
 if(m==11){for(int j=1;j<=m;j++)if(__builtin_popcount(word[j])>1)return false;return true;}
 if(m==20){for(int j=1;j<=m;j++)if(__builtin_popcount(word[j]&~1)>1)return false;return true;}
 return false;
}
int margin(int m){
 // milli-nats. These three shifted masks are singled out, all others need 70.
 constexpr int D12[]={0,1,2,3,4,8,16,32,64,128,256,512};
 constexpr int D18[]={0,1,2,3,4,5,8,9,16,17,32,33,64,65,128,129,256,257};
 constexpr int D19[]={0,1,2,3,4,5,8,9,16,17,32,33,64,65,128,129,256,257,512};
 if(m==12&&std::equal(word+1,word+1+m,D12))return 34;
 if(m==18&&std::equal(word+1,word+1+m,D18))return 45;
 if(m==19&&std::equal(word+1,word+1+m,D19))return 34;
 return 69;
}
void dfs(int x,int m,u64 need){
 word[m]=x;
 const bool test=(need>>m)&1;
 for(int y=0;y<N;y++)G[y]+=K[x^y];
 if(test && shape_all_ok[m] && !critical(m)){
  I r=0;u64 k=n*m;
  for(int y=0;y<N;y++){
   u64 g=G[y];
   if(g)r+=(U)g*negative_log_lower(g+k);
  }
  ++total_eval;
  I q=r-req[m]-(I(L)*Q*margin(m)+999)/1000;
  if(q<=0)shape_all_ok[m]=false;
  mn[m]=std::min(mn[m],q);
 }
 if(m<mmax){
  for(int i=0;i<nc[x];i++)pred[child[x][i]]--;
  for(int y=x+1;y<N;y++)if(pred[y]==0)dfs(y,m+1,need);
  for(int i=0;i<nc[x];i++)pred[child[x][i]]++;
 }
 for(int y=0;y<N;y++)G[y]-=K[x^y];
}
void band(u64 a,u64 b,u64 active){
 assert(a<b);
 auto hl=entropy(a),hh=entropy(b);u64 need=0;
 ++tried_intervals;
 for(int m=ni;m<=nj;m++)if((active>>m)&1){
  int t=upper_t[m],d=den_t[m];
  // H(P)>=ln(m) already proves some size/interval combinations.
  if(t<=0){
   assert(I((m>=2?d:0)-t)*m*1000*(ln2.first-hh.second)>I(d)*L*69);
   completed[m]+=b-a;++accepted[m];continue;
  }
  if((I(d)*logm[m].first-I(t)*ln2.second-I(n*d-t)*hh.second)*m*1000>I(d)*L*69){
    completed[m]+=b-a;++accepted[m];
  } else need|=1ULL<<m;
 }
 if(!need)return;
 u64 c=(a+b)/2;
 auto hm=entropy(c);
 mmax=63-__builtin_clzll(need);
 setup_kernel(c);
 for(int m=ni;m<=nj;m++)if((need>>m)&1){
  shape_all_ok[m]=true;mn[m]=I(1)<<120;
  int t=upper_t[m],d=den_t[m];
  // In h-coordinate, the gap derivative is between t/d - n and t/d.
  I slopeL=I(t)*(hm.second-hl.first);
  I slopeR=I(n*d-t)*(hh.second-hm.first);
  // Convert from gap units scaled by L*d to units scaled by L*m*Q.
  I base=I(t)*ln2.second+I(n*d-t)*hm.second-I(d)*logm[m].first+std::max(slopeL,slopeR);
  assert(base>0);
  req[m]=(base*m*Q)/d; // strict 'r>req' implies r exceeds the exact rational threshold.
  ++checked[m];
 }
 dfs(0,1,need);
 if((++evaluations%25)==0){std::fprintf(stderr,"tests=%llu intervals=%llu p=%0.8f..%0.8f total_shapes=%llu\n",(unsigned long long)evaluations,(unsigned long long)tried_intervals,(double)a/D,(double)b/D,(unsigned long long)total_eval);}
 u64 fail=0;
 for(int m=ni;m<=nj;m++)if((need>>m)&1){
  if(shape_all_ok[m]){completed[m]+=b-a;++accepted[m];}
  else fail|=1ULL<<m;
 }
 if(fail){
  if(b-a<=1){
   std::fprintf(stderr,"FAILED [%llu,%llu] / %llu:",(unsigned long long)a,(unsigned long long)b,(unsigned long long)D);
   for(int m=ni;m<=nj;m++)if((fail>>m)&1)std::fprintf(stderr," m=%d",m);
   std::fputs("\n",stderr); std::exit(2);
  }
  assert(a<c&&c<b);band(a,c,fail);band(c,b,fail);
 }
}
int main(int argc,char**argv){
 assert(argc==8);
 ni=atoi(argv[1]);nj=atoi(argv[2]);int x=atoi(argv[3]),y=atoi(argv[4]);hexp=atoi(argv[5]);num=atoi(argv[6]);den=atoi(argv[7]);
 assert(1<=ni&&ni<=nj&&nj<=M&&0<=hexp&&hexp<=27&&0<=x&&x<y&&y<=int(1ULL<<hexp)/2);
 u64 a=u64(x)<<(27-hexp),b=u64(y)<<(27-hexp);
 assert(num>0&&num<=3*den&&den>0&&den<=1000000);
 ln2=logsmall(2,1);for(int m=1;m<=M;m++)logm[m]=logint(m);
 for(int j=0;j<=1<<J;j++){tabhi[j]=logsmall((1<<J)+j,1<<J).second;recip[j]=ce(L,(1<<J)+j);}
 for(int t=1;t<N;t++){
  if(t&1){int p=t-1;child[p][nc[p]++]=t;++pred[t];}
  for(int j=1;j<n;j++)if(((t>>(j-1))&3)==2){int p=t-(1<<(j-1));child[p][nc[p]++]=t;++pred[t];}
  assert(pred[t]>0);
 }
 u64 mask=0;
 for(int m=ni;m<=nj;m++){

  upper_t[m]=(4*den+num)*m-(m==M?0:16*num);den_t[m]=den*m;
  mask|=1ULL<<m;
 }
 band(a,b,mask);
 for(int m=ni;m<=nj;m++){assert(completed[m]==b-a);std::printf("m=%d slices=%lld evaluated=%lld\n",m,accepted[m],checked[m]);}
 std::printf("DONE all m=%d..%d (critical shapes omitted) on [%d,%d]/2^%d at lambda=%d/%d; nodes=%llu; evaluated shape-crossover pairs=%llu\n",
   ni,nj,x,y,hexp,num,den,(unsigned long long)tried_intervals,(unsigned long long)total_eval);
}
