"""Sharper exact two-point inverse-compression margin by weighted cut bounds."""
from itertools import combinations
from fractions import Fraction as F
from sys import argv
lo=F(20201,65536)
hi=F(argv[1]) if len(argv)>1 else F(5,16)
assert lo<hi<F(1,2)
Q=1<<52
A={0}|{1<<j for j in range(10)}
B={0,1}|{x^(1<<j) for j in range(1,10) for x in (0,1)}
C=set(range(16))
D12=A|{3}
D18={0,1}|{x^(1<<j) for j in range(1,9) for x in (0,1)}
D19=D18|{512}
def ceil(x):return -(-x.numerator//x.denominator)
Ku=[ceil(Q*hi**d*(1-lo)**(10-d)) for d in range(11)]
for name,S,groups in [('A',A,[0]*10),('B',B,[0]+[1]*9),('F',C,[0]*4+[1]*6),('D12',D12,[0]*2+[1]*8),('D18',D18,[0]+[1]*8+[2]),('D19',D19,[0]+[1]*8+[2])]:
    seen=set();best=None
    rows=[]
    for i in range(10):rows.append((i,None,0,1))
    for i,j in combinations(range(10),2):
        for sign in (0,1):rows.append((i,j,sign,2))
    for i,j,sign,r in rows:
        typ=(groups[i],None if j is None else groups[j],sign,r)
        if typ in seen:continue
        seen.add(typ)
        if j is None:
            sig=lambda x: x^(1<<i)
        else:
            sig=lambda x: x^((((x>>i)^(x>>j)^sign)&1)*((1<<i)|(1<<j)))
        X=[x for x in S if sig(x) not in S];u=len(X)
        if u<2 or len({x>>i&1 for x in X})!=1:continue
        ori=(X[0]>>i)&1
        Ys=[y for y in range(1024) if (y>>i)&1==ori and sig(y)!=y]
        Dl=[int(Q*(1-2*hi)*lo**d*(1-hi)**(10-r-d)) for d in range(11-r)]
        w=[[0]*u for _ in X]
        for y in Ys:
            Gy=sum(Ku[(x^y).bit_count()]+Ku[(x^sig(y)).bit_count()] for x in S)
            d=[Dl[(x^y).bit_count()] for x in X]
            for x in range(u):
                for z in range(x):
                    w[x][z]+=2*d[x]*d[z]//Gy
        for x in range(u):
            for z in range(x):w[z][x]=w[x][z]
        mindeg=min(map(sum,w))
        minedge=min(w[x][z] for x,z in combinations(range(u),2))
        maxedge=max(w[x][z] for x,z in combinations(range(u),2))
        cut=min(max(k*(u-k)*minedge,k*mindeg-k*(k-1)*maxedge) for k in range(1,1+u//2))
        val=F(cut,Q)
        if best is None or val<best:best=val;bk=(i,j,sign)
        print(name,i,j,sign,'u',u,'cut',float(val))
    assert best>({"D18": F(25,1000), "D12": F(36,1000), "D19": F(36,1000)}.get(name, F(1,10)))
    print(name,'minimum weighted inverse-compression gain',best,float(best),'at',bk)
