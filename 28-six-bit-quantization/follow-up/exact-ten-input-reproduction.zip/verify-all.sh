#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
temp=$(mktemp -d)
trap 'rm -r "$temp"' EXIT
g++ -O3 -std=c++17 verify-ten-band.cpp -o "$temp/plain"
g++ -O3 -std=c++17 -DTANGENT verify-ten-band.cpp -o "$temp/tangent"
g++ -O3 -std=c++17 -DTANGENT verify-late-margin.cpp -o "$temp/late"
g++ -O3 -std=c++17 -DTANGENT verify-partition-gap.cpp -o "$temp/partition"
for sizes in '1 19' '20 23' '24 34' '35 39' '40 43' '44 44'; do
    read -r a b <<< "$sizes"
    "$temp/plain" "$a" "$b" 0 77 8 10 7
    "$temp/tangent" "$a" "$b" 616 631 11 887 625
    "$temp/tangent" "$a" "$b" 20192 20201 16 141909 100000
    "$temp/partition" "$a" "$b" 20201 20224 16 141909 100000
    "$temp/late" "$a" "$b" 20201 20317 16 141926 100000
done
python3 verify-obstruction.py
python3 tiling-obstruction.py
python3 verify-gaps.py
python3 late-critical.py
python3 inverse-strong.py
python3 verify-single18.py
printf '%s\n' 'The separate earlier m=16 cell check is reproduced by: python3 prior-verify-balanced.py 10'
