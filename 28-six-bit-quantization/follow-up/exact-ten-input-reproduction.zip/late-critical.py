"""Verify the two critical cell slacks and the inverse-compression margin."""
from pathlib import Path
from itertools import combinations
from math import comb
from fractions import Fraction as F

# Use the exact common log enclosure; loading this prefix does not rerun its test.
src=Path(__file__).with_name('verify-obstruction.py').read_text()
exec(src[:src.index('# p >= 2/5')])

def clo(a):
    return LN2[0]+(a*lgn(a,P)[0]+(P-a)*lgn(P-a,P)[0])//P

@lru_cache(None)
def dup(d,a):
    D=P**d
    w=[a**r*(P-a)**(d-r) for r in range(d+1)]
    t=0
    for r in range(d+1):
        v=w[r]+(r*w[r-1] if r else 0)+((d-r)*w[r+1] if r<d else 0)
        t+=comb(d,r)*v*lgn((1<<d)*v,D*(d+1))[1]
    return ceil(t,D*(d+1))

gamma=F(1,64)
eta=F(1,15360)
lamb=F(141926,100000)
low=20201*(P//65536)
high=20317*(P//65536)
count=[0,0]
for row,(d,m) in enumerate(((10,11),(9,20))):
    t=4+lamb*(1-F(16,m))
    stack=[(low,high)]
    while stack:
        a,b=stack.pop()
        # C and D are nonincreasing in p. Strict inequality in nats.
        if (10-t)*clo(b)-dup(d,a)>-eta*W:
            count[row]+=1
        else:
            c=(a+b)//2
            assert a<c<b,(row,a,b)
            stack.extend(((a,c),(c,b)))
print('critical shape lower bounds -1/15360 nats:',count,'closed intervals')

