"""Independent integer verification when a unique D18 low-margin tile occurs."""
from fractions import Fraction as F
from pathlib import Path
import json
# Import only the standard-library tile enumeration, not its archived tests.
src=Path(__file__).with_name('tiling-obstruction.py').read_text()
exec(src[:src.index("entries=")])
D18={0,1}|{x^(1<<j) for j in range(1,9) for x in (0,1)}
rows=json.loads(Path(__file__).with_name('single18-duals.json').read_text())
required={(1<<(i+1))-2|j for i in range(9) for j in (0,512)
          if D18.isdisjoint(ball(((1<<(i+1))-2)|j))}
assert len(rows)==len(required) and {row[0] for row in rows}==required
for k,typ,scale,y in rows:
    assert scale>0 and typ in ('dual','farkas')
    covered=D18|set(ball(k))
    assert len(covered)==29
    masks=[m&v for m in [1,510,512] for v in [k,1023^k] if m&v]
    seen={};orb=[]
    for x in U:
        p=tuple((x&m).bit_count() for m in masks)
        orb.append(seen.setdefault(p,len(seen)))
    L=len(seen)
    assert len(y)==L+3
    for t,S in T:
        if covered.isdisjoint(S):
            assert y[L+t]+sum(y[orb[x]] for x in S)<=0
    assert -4*y[L]-5*y[L+1]+9*y[L+2]<=(-scale if typ=='dual' else 0)
    v=sum(y[orb[x]] for x in U if x not in covered)+y[L]+2*y[L+1]+59*y[L+2]
    if typ=='dual':
        lim=F(-v,scale)
        assert lim<5
        print(k,'requires q <=',lim)
    else:
        assert v>0
        print(k,'infeasible, Farkas contradiction',F(v,scale))
assert F(638,15360)<F(45,1000)
