"""Verify the two critical cell slacks and the inverse-compression margin."""
from pathlib import Path
from itertools import combinations
from math import comb
from fractions import Fraction as F

# Use the exact common log enclosure; loading this prefix does not rerun its test.
src=Path(__file__).with_name('verify-obstruction.py').read_text()
exec(src[:src.index('# p >= 2/5')])

def clo(a):
    return LN2[0]+(a*lgn(a,P)[0]+(P-a)*lgn(P-a,P)[0])//P

@lru_cache(None)
def dup(d,a):
    D=P**d
    w=[a**r*(P-a)**(d-r) for r in range(d+1)]
    t=0
    for r in range(d+1):
        v=w[r]+(r*w[r-1] if r else 0)+((d-r)*w[r+1] if r<d else 0)
        t+=comb(d,r)*v*lgn((1<<d)*v,D*(d+1))[1]
    return ceil(t,D*(d+1))

gamma=F(1,64)
eta=gamma/1024
lamb=F(141909,100000)
low=20201*(P//65536)
high=20224*(P//65536)
count=[0,0]
for row,(d,m) in enumerate(((10,11),(9,20))):
    t=4+lamb*(1-F(16,m))
    stack=[(low,high)]
    while stack:
        a,b=stack.pop()
        # C and D are nonincreasing in p. Strict inequality in nats.
        if (10-t)*clo(b)-dup(d,a)>-eta*W:
            count[row]+=1
        else:
            c=(a+b)//2
            assert a<c<b,(row,a,b)
            stack.extend(((a,c),(c,b)))
print('critical shape lower bounds -1/65536 nats:',count,'closed intervals')

A={0}|{1<<j for j in range(10)}
B={0,1}|{e^(1<<j) for e in [0,1] for j in range(1,10)}
C=set(range(16))
p=F(3,10)
assert (1-p)**10+10*p*(1-p)**9<F(1,5)
assert (1-p)**9+9*p*(1-p)**8<F(1,5)
assert (1-p)**6<F(1,5)
assert F(low,P)>=p and F(high,P)<=F(31,100)
assert 2*p*(1-p)>=F(21,50)
assert 1-2*F(31,100)*F(69,100)>=F(57,100)
assert 1-2*F(31,100)==F(19,50)

def score(X,changed):
    assert len(X)>=2
    d=max((x^y).bit_count() for x in X for y in X)
    e=10-changed-d
    assert e>=0
    return 5*(len(X)-1)*F(19,50)**2*F(21,50)**d*F(57,100)**e
for name,S in [('A',A),('B',B),('F',C)]:
    vals=[]
    for i in range(10):
        X=[x for x in S if x^(1<<i) not in S]
        if len(X)>1 and len({x>>i&1 for x in X})==1:
            vals.append(score(X,1))
    for i,j in combinations(range(10),2):
        for sign in [0,1]:
            def swap(x):
                flip=((x>>i)^(x>>j)^sign)&1
                return x^(flip*((1<<i)|(1<<j)))
            X=[x for x in S if swap(x) not in S]
            if len(X)>1 and len({x>>i&1 for x in X})==1:
                vals.append(score(X,2))
    g=min(vals)
    print(name,'two-point compression m*entropy margin at least',g)
    assert g>gamma
assert F(19,50)**2/128>eta
