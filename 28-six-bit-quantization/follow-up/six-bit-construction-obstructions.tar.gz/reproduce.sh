#!/bin/sh
# Run from this directory. C++17 and stock Python 3.10+; no packages.
set -eu
CXX=${CXX:-c++}
"$CXX" -O3 -std=c++17 enumerate-shifted.cpp -o enumerate-shifted
./enumerate-shifted > extrema.txt
python3 graph-orbits.py
"$CXX" -O3 -std=c++17 verify-tiling.cpp -o verify-tiling
./verify-tiling < graph-orbits.txt
./enumerate-shifted --near > near-shapes.txt
python3 near-summary.py
"$CXX" -O3 -std=c++17 affine-cover.cpp -o affine-cover
./affine-cover
