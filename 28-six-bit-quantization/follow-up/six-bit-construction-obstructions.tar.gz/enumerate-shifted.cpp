// All shifted (strongly stable) 64-point ideals in the 12-coordinate cube.
// Stable predecessors: delete bit 0, or move a bit down one unoccupied position.
#include <cstdio>
#include <cassert>
#include <algorithm>
using namespace std;
constexpr int n=12,N=4096,m=64;
int pre[N],nodes[m],s[n],frontier[m+1][128],fi[m+1],child[N][n],nc[N];
int cutoff=6*m*m;
long long total=0,good=0,equalCount=0;
void visit(int depth,int x){
 nodes[depth-1]=x;
 for(int i=0;i<n;i++) s[i]+=1-2*(x>>i&1);
 if(depth==m){
  total++;int B=0;for(int t:s)B+=t*t;
  if(B>=cutoff){
   if(B>6*m*m){good++;}else if(B==6*m*m){equalCount++;}
   printf("%d",B);for(int k:nodes)printf(" %d",k);puts("");
  }
 }else{
  auto *V=frontier[depth];int k=0;
  for(int i=0;i<fi[depth-1];i++)if(frontier[depth-1][i]>x)V[k++]=frontier[depth-1][i];
  for(int i=0;i<nc[x];i++){int y=child[x][i];if(!--pre[y])V[k++]=y;}
  assert(k<128);fi[depth]=k;
  for(int i=0;i<k;i++)visit(depth+1,V[i]);
  for(int i=0;i<nc[x];i++)++pre[child[x][i]];
 }
 for(int i=0;i<n;i++) s[i]-=1-2*(x>>i&1);
}
int main(int argc,char**){
 if(argc>1)cutoff-=96;
 for(int y=1;y<N;y++){
  auto edge=[&](int x){child[x][nc[x]++]=y;++pre[y];};
  if(y&1)edge(y-1);
  for(int j=1;j<n;j++)if((y>>j&1)&&!(y>>(j-1)&1))edge(y-(1<<(j-1)));
 }
 visit(1,0);fprintf(stderr,"shifted %lld, strict %lld, level %lld\n",total,good,equalCount);
 assert(total==1027170 && good==12);
}
