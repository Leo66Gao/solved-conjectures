"""Enumerate isomorphism classes of favorable 15-edge missing-pair graphs."""
from itertools import combinations
from pathlib import Path
from functools import lru_cache
n=12
def canon(G):
    def refine(P):
        while True:
            D=[{} for _ in P]
            for i,c in enumerate(P):
                for x in c:
                    sig=tuple((G[x]&sum(1<<v for v in b)).bit_count() for b in P)
                    D[i].setdefault(sig,[]).append(x)
            Q=[g[k] for g in D for k in sorted(g)]
            if len(Q)==len(P):return P
            P=Q
    def go(P):
        P=refine(P)
        for i,g in enumerate(P):
            if len(g)==1:continue
            a=g[0]
            if all(not ((G[x]^G[a])&~((1<<a)|(1<<x))) for x in g):continue
            return min(go(P[:i]+[[x],[y for y in g if y!=x]]+P[i+1:]) for x in g)
        v=sum(P,[]);return tuple(sum(1<<j for j,y in enumerate(v) if G[x]>>y&1) for x in v)
    return go([list(range(n))])
def read():
    gs=set()
    for line in Path('extrema.txt').read_text().splitlines():
        val,*xs=map(int,line.split()); A=set(xs)
        if max(a.bit_count() for a in A)>2:
            assert A==set(range(64));continue
        G=[0]*n
        for i,j in combinations(range(n),2):
            if (1<<i|1<<j) not in A:G[i]|=1<<j;G[j]|=1<<i
        gs.add(canon(G))
    q=list(gs)
    for G in q:
        d=[g.bit_count() for g in G]; S=sum(t*t for t in d); assert S>=144
        for i,j in combinations(range(n),2):
            a=G[i]&~G[j]&~(1<<j);b=G[j]&~G[i]&~(1<<i)
            if bool(a)==bool(b):continue
            x,y=(i,j) if a else (j,i)
            m=a|b; h=m.bit_count(); ss=m
            while ss:
                s=ss.bit_count()
                if 0<s<=h//2 and S-2*s*(h-s)>=144:
                    T=list(G);T[x]^=ss;T[y]^=ss
                    for v in range(n):
                        if ss>>v&1:T[v]^=1<<x|1<<y
                    c=canon(T)
                    if c not in gs:gs.add(c);q.append(c)
                ss=(ss-1)&m
    return sorted(gs)
if __name__=='__main__':
    gs=read();print('orbits',len(gs))
    with open('graph-orbits.txt','w') as f:
        for G in gs:print(*G,file=f)
