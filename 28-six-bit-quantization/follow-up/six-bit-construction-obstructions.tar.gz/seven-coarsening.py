"""Exact certificate for all six-bit coarsenings of the seven-bit example on p∈[2/5,1/2]. Python 3.10+.
Uses integer channel weights throughout; log enclosures use no floating point.
"""
from collections import Counter
from itertools import product
from fractions import Fraction as F
from functools import lru_cache
from math import ceil

n=14
N=1<<n
def encode(a,b,c,d):
    z=(a,b,c,d,2*a+b+c+d,3*a+2*b+c+3*d,3*a+3*b+2*c+d,3*a+b+3*c+2*d)
    return sum(((t%4)^((t%4)>>1))<<(2*i) for i,t in enumerate(z))
C=sorted({w>>2 for t in product(range(4),repeat=4)
                 if ((w:=encode(*t))&1)==0})
assert len(C)==128
cells={c:[] for c in C}
taken=set()
for e in sorted(range(N),key=lambda z:(z.bit_count(),z)):
    for c in C:
        x=c^e
        if x not in taken:
            cells[c].append(x); taken.add(x)
    if len(taken)==N: break
assert {len(xs) for xs in cells.values()}=={128}
# Pairwise centroid contrasts, evaluated on the two endpoint correlations.
Sums=[]; Corr=[]
for xs in cells.values():
    signs=[[1-2*((x>>i)&1) for i in range(n)] for x in xs]
    Sums.append([sum(v[i] for v in signs) for i in range(n)])
    Corr.append([[sum(v[i]*v[j] for v in signs) for j in range(n)] for i in range(n)])
from itertools import combinations
B=F(sum(t*t for s in Sums for t in s),128**3)
minD=None; bound=None; margin=F(21,20)
for i,j in combinations(range(128),2):
    a=[x-y for x,y in zip(Sums[i],Sums[j])]
    norm=sum(x*x for x in a)
    dsq=F(norm,128**2)
    minD=dsq if minD is None else min(minD,dsq)
    # On the equal mixture of inputs from cells i and j:
    e2=F(sum(a[h]*a[k]*(Corr[i][h][k]+Corr[j][h][k]) for h in range(n) for k in range(n)),256)
    mu=F(sum(a[h]*(Sums[i][h]+Sums[j][h]) for h in range(n)),256)
    var2=e2-mu*mu
    ymax=max(norm,F(24,25)*norm+F(1,25)*var2)
    local=F(norm,128)**2/(8*ymax)
    bound=local if bound is None else min(local,bound)
assert B==F(28747,4096) and minD==F(289,32)
assert B-minD/4==F(19499,4096)
assert bound>margin
print('Original B:',B,'minimum centroid distance squared:',minD,'coarse B bound:',B-minD/4)
print('For 0<rho<=1/5, all pairwise JS / rho^2 >=',bound,'> 21/20.')
h=Counter()
for xs in cells.values():
    mass=[0]*N
    for x in xs: mass[x]=1
    for i in range(n):
        bit=1<<i
        for j in range(0,N,2*bit):
            for a in range(j,j+bit):
                b=a+bit; x,y=mass[a],mass[b]
                mass[a],mass[b]=3*x+2*y,2*x+3*y
    assert sum(mass)==128*5**n
    h.update(mass)

# Enclose log(num/den)*S above and below by integers.
S=1<<60
def up(a,b):return -(-a//b)
def unitlog(a,b):
    assert b<=a<=2*b
    r,t=a-b,a+b         # z=r/t in [0,1/3]
    lo=hi=0; R=r; T=t
    for j in range(1,32,2):
        lo+=2*S*R//(j*T)
        hi+=up(2*S*R,j*T)
        R*=r*r; T*=t*t
    # Remaining odd terms start with z^33/33 and converge geometrically.
    hi+=up(2*S*R*t*t,33*T*(t*t-r*r))
    return lo,hi
L2,U2=unitlog(2,1)
@lru_cache(None)
def logiv(a,b):
    k=0
    while a<b:a*=2;k-=1
    while a>=2*b:b*=2;k+=1
    l,h=unitlog(a,b)
    return l+min(k*L2,k*U2),h+max(k*L2,k*U2)
M=128*5**n
# P(y|u)=w/M, Pr(U=u,Y=y)=w/(128*M), P(y)=1/N.
mi0=mi1=0
for w,t in h.items():
    l,u=logiv(N*w,M)
    mi0+=t*w*l;mi1+=t*w*u
lo=F(mi0,128*M*S);hi=F(mi1,128*M*S)

assert hi<F(141,1000)
assert 25*F(141,1000)-F(65,128)*margin<3
print('At rho=1/5 original mutual information < 141/1000 nats.')
print('All six-bit coarsenings: I/rho^2 <',25*F(141,1000)-F(65,128)*margin,'<3 nats.')
