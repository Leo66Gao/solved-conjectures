# Merging labels of the seven-bit counterexample does not give a six-bit counterexample at high noise

Let V be the specific balanced, 128-valued quantizer of 14 independent fair input bits in [the seven-bit construction](https://github.com/Leo66Gao/solved-conjectures/tree/main/15-seven-bit-quantizer), and let Y be their binary symmetric channel output with ρ=1−2p. Logarithms in the proof below are natural. For **every** grouping U of its 128 labels into at most 64 groups,

    I(U;Y) < (7659/2560)ρ² < 3ρ² ≤ 6[ln 2−h(p)]       (0<ρ≤1/5).

At ρ=0 both sides of the coordinate comparison vanish. Thus neither the known example at p=2/5 nor the interval near complete noise can be inherited by simply relabeling or merging output cells, even very unevenly. This does not apply to repartitioning the individual input points inside those cells. The same upper bound holds if postprocessing is randomized: a stochastic channel on finitely many labels is a mixture of deterministic maps using an independent seed; disclosing the seed can only increase information.

## Quadratic obstruction

Write bᵢ∈ℝ¹⁴ for the vector of conditional mean input signs given original label i, and B(V)=Σᵢ||bᵢ||²/128. Exact counts give B(V)=28747/4096 and the smallest pairwise squared separation d=289/32. For a group of t labels the variance lost by averaging its centroids is t⁻² Σ_{i<j in group}||bᵢ−bⱼ||²≥(t−1)d/(2t). Weight by t/128 and sum. With K≤64 groups this costs at least (128−K)d/256≥d/4, so the coarse coefficient is at most 19499/4096. This bound need not be attained.

## Finite-noise obstruction

Let Pᵢ be the noisy conditional distribution from label i and let JS(Pᵢ,Pⱼ)=H((Pᵢ+Pⱼ)/2)−(H(Pᵢ)+H(Pⱼ))/2. For each nonsingleton group, the equally weighted mixture of all its distinct unordered pair-mixtures equals the whole group mixture. By entropy concavity, the group's increase in output entropy relative to its individual cells is at least the smallest pairwise JS. At most 63 of the original labels can lie in singleton groups: there are at most 64 groups and at least one must be nonsingleton. Therefore I(V;Y)−I(U;Y)≥(65/128) min_{i≠j} JS(Pᵢ,Pⱼ).

Here is a short exact certificate of the pair bound over the entire interval. Put M=(Pᵢ+Pⱼ)/2, and z=(Pᵢ−Pⱼ)/(Pᵢ+Pⱼ) on its support. Conditional on Y in a fair binary experiment distinguishing these labels, z is the posterior mean sign. In nats the binary information φ(z)=[(1+z)ln(1+z)+(1−z)ln(1−z)]/2 is at least z²/2. For any real contrast T(Y), centering at E_M T and using Cauchy–Schwarz gives

    JS(Pᵢ,Pⱼ) ≥ [Eᵢ T−Eⱼ T]² / [8 Var_M(T)].

Let a=128(bᵢ−bⱼ), a vector of integers, and take T(Y)=Σ_h a_h (−1)^Y_h. Its mean separation is ρ||a||²/128. If V_X is the variance of the same input contrast under the equal two-cell mixture, then Var_M(T)=(1−ρ²)||a||²+ρ² V_X, by conditional variance and independence of the flips. The maximum on 0≤ρ²≤1/25 occurs at an endpoint. Computing the 128 original cell sign sums and 14-by-14 second moment matrices, the exact minimum over all 8,128 pairs of the resulting lower bound for JS/ρ² is 835210/789763>21/20.

For completeness, a binary symmetric channel with correlation α contracts divergence to the uniform cube by at least the factor α², in the sense D(T_α P||unif)≤α² D(P||unif). In one bit this is φ(αb)≤α²φ(b) from the even series with positive coefficients. In several bits, apply the one-bit contraction to the i-th conditional output law given earlier noisy coordinates. The corresponding average divergence of the conditional input given those noisy coordinates is no greater than conditioning on the earlier *input* coordinates, by convexity or information processing; then sum the chain rule. Apply this separately to the 128 conditional output laws and use the BSC semigroup: for 0≤ρ≤1/5 one has I(V;Y_ρ)≤25ρ² I(V;Y_{1/5}).

At correlation 1/5 the original mutual information is strictly below 141/1000 nats. The supplied script verifies this with integer BSC convolution and outward logarithm enclosures (and independently regenerates the codewords, cells, centroids and second moments). Combining bounds gives I(U;Y)/ρ²<25·141/1000−(65/128)(21/20)=7659/2560. Finally ln 2−h(p)=φ(ρ)≥ρ²/2, as claimed.

**Reproduce:** `python3 seven-coarsening.py` using the Python standard library. Expected output is in `coarsening.log`. This is an obstruction for a specified construction, not a resolution of the unrestricted six-bit problem.
