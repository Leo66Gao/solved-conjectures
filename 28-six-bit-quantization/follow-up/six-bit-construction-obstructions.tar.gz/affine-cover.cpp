// Exhaust all 12-point subsets of F_2^6 minus 0 containing the six unit vectors.
// A radius-2 affine [12,6] covering code would yield a covering syndrome set.
#include <cstdint>
#include <cstdio>
#include <cassert>
#include <algorithm>
using namespace std;
using W=uint64_t;
int cols[12]={1,2,4,8,16,32}, pool[57],total=0,best=0;
W bit(int x){return W(1)<<x;}
void go(int depth,int start,W seen){
 if(depth==12){++total;best=max(best,__builtin_popcountll(seen));return;}
 for(int j=start;j<=57-(12-depth);++j){
  int x=pool[j];W s=seen|bit(x);
  for(int i=0;i<depth;i++)s|=bit(x^cols[i]);
  cols[depth]=x;go(depth+1,j+1,s);
 }
}
int main(){
 int q=0;for(int x=1;x<64;x++)if(x&(x-1))pool[q++]=x;assert(q==57);
 W s=bit(0);for(int i=0;i<6;i++){s|=bit(cols[i]);for(int j=0;j<i;j++)s|=bit(cols[i]^cols[j]);}
 go(6,0,s);
 printf("%d systematic presentations; max covered syndromes %d of 64.\n",total,best);
 assert(total==36288252&&best<64);
}
