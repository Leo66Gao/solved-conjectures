# Six-bit quantization: three exact construction obstructions

1. [Twelve inputs, arbitrary translational one-template partitions](translational-quantizers.md): complete structural classification of the 64-point cells with bias coefficient at least six; only a coordinate face can tile by translations. Includes the explicit mutual-information interval 0≤1−2p≤1/512.
2. [Two differently shaped templates with a common period of dimension five](mixed-periodic-quantizers.md): no high-noise counterexample for these balanced mixed partitions of Q12, including different orientations.
3. [Every six-bit coarsening of the solved seven-bit example](seven-coarsening-all.md): even unbalanced or randomized postprocessing is strictly worse at **every** interior crossover. A shorter independent high-noise proof gives the explicit coefficient deficit.

To rebuild the certificates, run `sh reproduce.sh` and `python3 seven-coarsening.py`, then run `sh reproduce.sh` in the `coarsening-all` subdirectory. Requirements: C++17 and Python 3.10+ standard library, with assertions enabled. Both terminate in seconds on a modern CPU. The graph and shifted data files are reproducible outputs, not external inputs. No unrestricted six-bit counterexample is claimed.
