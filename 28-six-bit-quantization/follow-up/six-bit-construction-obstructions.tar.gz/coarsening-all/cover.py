from math import isqrt
from fractions import Fraction as F
from functools import lru_cache
import sys
# Natural logs at scale R, with range reduced to small ratios.
R=1<<54
def ceil(a,b):return -(-a//b)
def logunit(a,b):
 u=a-b;v=a+b; L=U=0;A=u;B=v
 for k in range(1,40,2):
  L+=2*R*A//(k*B);U+=ceil(2*R*A,k*B)
  A*=u*u;B*=v*v
 return L,U+ceil(2*R*A*v*v,41*B*(v*v-u*u))
TAB=[logunit(256+i,256) for i in range(257)];l2,h2=TAB[-1]
def logs(a,b):
 assert a>0 and b>0
 k=a.bit_length()-b.bit_length()
 if k<0:a=a<<(-k)
 else:b=b<<k
 if a<b:k-=1;a*=2
 j=256*a//b;ta,tb=256*a-j*b,j*b
 # ln(1+t), 0<=t<1/256, lower/upper alternating sums through 4 and 3.
 t=R*ta//tb
 # use the exact cubic at t (integer fixed point); the true t is <(t+1)/R
 c=R**2
 v=(6*c*t-3*R*t*t+2*t*t*t)//(6*c)
 corr=ceil((t+1)**4,4*R**3)
 lo,hi=TAB[j-256];return lo+min(k*l2,k*h2)+v-corr,hi+max(k*l2,k*h2)+v+2
def phi_cap_lo(p):
 a,b=p.numerator,p.denominator
 return F(b*l2 +a*logs(a,b)[0]+(b-a)*logs(b-a,b)[0],b*R)
def data():
 single=[];pairs=[]
 for line in open('single-hist.txt'):
  c,*v=map(int,line.split());single.append((c,v))
 with open('pair-hist.txt') as f:
  while (q:=f.readline()):
   part=[]
   for _ in range(int(q)):
    row=list(map(int,f.readline().split()));part.append((row[:15],row[15:]))
   pairs.append(part)
 assert len(single)==4324 and len(pairs)==568
 return single,pairs
single,pairs=data()
def point(p):
 a,b=p.numerator,p.denominator;ker=[a**j*(b-a)**(14-j) for j in range(15)]
 M=128*b**14
 def wt(v):return sum(x*y for x,y in zip(v,ker))
 mi=sum(c*w*logs(16384*w,M)[1] for c,v in single if (w:=wt(v)))
 mi=F(mi,128*M*R)
 # All bin probabilities are w/M. Use per-bin upper affinity and lower JS.
 worstJS=1;worstA=0
 for g in pairs:
  s=af=0
  for v,z in g:
   x,y=wt(v),wt(z);t=x+y
   s+=x*logs(2*x,t)[0]+y*logs(2*y,t)[0]
   af+=isqrt(R*R*x*y)+1
  worstJS=min(worstJS,F(s,2*M*R));worstA=max(worstA,F(af,M*R))
 gamma=10
 for m in range(2,66):
  q=(1+(m-1)*worstA)/m
  j2=F(-logs(q.numerator,q.denominator)[1],R)
  gamma=min(gamma,F(m,2*(m-1))*max(j2,worstJS))
 return mi-gamma
if __name__=='__main__':
 begin=F(1,32768);xs=(list(map(F,sys.argv[1:])) if len(sys.argv)>1 else [begin])
 for p in xs:
  u=point(p);b=u/(1-2*p)**2
  lo=p;hi=F(1,2)
  if b>3:
   for _ in range(26):
    v=(lo+hi)/2
    if 6*phi_cap_lo(v)/(1-2*v)**2>=b:lo=v
    else:hi=v
  else:lo=hi
  print(p, 'bound normalized',round(float(b),9),'extends',round(float(lo),10),flush=True)
