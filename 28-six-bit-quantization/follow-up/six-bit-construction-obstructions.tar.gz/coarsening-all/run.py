from cover import *
p=F(1,32768);N=1<<20; k=0
# Discrete entropy gap for any nonbalanced 64-group coarsening at low crossover.
L0=F(3*logs(3,1)[0]-4*h2,128*R)
assert L0>F(1,256) and 6*p*(15*F(h2,R)+1)<F(1,256)
# Every balanced coarsening groups into pairs, each with boundary >=2462/256.
assert F(2462,256)>F(19,2) and (1-13*p)>F(999,1000)
assert F(19,2)*F(999,1000)*(10-3)>6*(10+1)
print('low end certified through 1/32768',flush=True)
while True:
 u=point(p);b=u/(1-2*p)**2;k+=1
 if b<3:
  print(k,str(p),'-> 1/2 minimum certified coordinate margin',float(3-b),'nats/rho^2',flush=True);break
 lo=p;hi=F(1,2)
 for _ in range(28):
  v=(lo+hi)/2
  if 6*phi_cap_lo(v)/(1-2*v)**2>b:lo=v
  else:hi=v
 q=F(int(N*(lo*15+p)/16),N)
 assert q>p and 6*phi_cap_lo(q)/(1-2*q)**2>b
 print(k,str(p),'->',str(q),'min margin',float(6*phi_cap_lo(q)/(1-2*q)**2-b),flush=True)
 p=q
 assert k<50
