#include <bits/stdc++.h>
using namespace std;
using H=array<int,15>;constexpr int N=1<<14;
int main(){
 vector<int>C;for(int u=0;u<256;u++){int v[8];for(int i=0;i<4;i++)v[i]=u>>(2*i)&3;
 int a=v[0],b=v[1],c=v[2],d=v[3];v[4]=2*a+b+c+d;v[5]=3*a+2*b+c+3*d;v[6]=3*a+3*b+2*c+d;v[7]=3*a+b+3*c+2*d;
 int w=0;for(int i=0;i<8;i++){int v0=v[i]%4;w|=(v0^(v0>>1))<<(2*i);}if(!(w&1))C.push_back(w>>2);}
 sort(C.begin(),C.end());set<int>codes(C.begin(),C.end());vector<int>K;
 for(int a:C){bool ok=true;for(int b:C)ok&=codes.count(a^b);if(ok)K.push_back(a);}
 assert(C.size()==128&&codes.size()==128&&K.size()==16);
 map<int,int>U;map<int,vector<int>>sets;
 vector<int>cent(N);for(int x=0;x<N;x++){int e=N,wt=15;for(int c:C){int f=c^x,k=__builtin_popcount(f);if(k<wt||(k==wt&&f<e))wt=k,e=f;}cent[x]=x^e;sets[x^e].push_back(x);}

 // Directed edge boundary of each union of two original labels.
 map<int,int>id;
 for(int t=0;t<128;t++)id[C[t]]=t;
 int edge[128][128]={},min_boundary=10000;
 for(int x=0;x<N;x++)for(int bit=0;bit<14;bit++)++edge[id[cent[x]]][id[cent[x^(1<<bit)]]];
 for(int i=0;i<128;i++)for(int j=i+1;j<128;j++)min_boundary=min(min_boundary,14*256-edge[i][i]-edge[j][j]-edge[i][j]-edge[j][i]);
 assert(min_boundary==2462);cerr<<"minimum pair-cell directed edge boundary: "<<min_boundary<<"/256 per word\n";
 for(int c:C)assert(sets[c].size()==128);
 set<int>reps;map<int,int>rep;for(int c:C){int v=N;for(int t:K)v=min(v,c^t);rep[c]=v;reps.insert(v);}
 map<int,vector<H>> hs;map<H,int>types;map<int,vector<long long>> wt;int pw[15]={1};for(int i=1;i<15;i++)pw[i]=pw[i-1]*3;
 for(int c:reps){auto &rows=hs[c];rows.resize(N);wt[c].resize(N);for(int y=0;y<N;y++){
  for(int x:sets[c])rows[y][__builtin_popcount(x^y)]++;
  types[rows[y]]+=16;for(int k=0;k<15;k++)wt[c][y]+=rows[y][k]*pw[14-k];
 }}
 ofstream f("single-hist.txt");for(auto&q:types){f<<q.second;for(int k:q.first)f<<" "<<k;f<<"\n";}
 ofstream out("pair-hist.txt");set<pair<int,int>> pairs;for(int i:C)for(int j:C)if(i<j){
  pair<int,int> a={N,N};for(int k:K){int x=i^k,y=j^k;a=min(a,make_pair(min(x,y),max(x,y)));}pairs.insert(a);
 }
 int B=0;for(auto [i,j]:pairs){
  int ci=rep[i],cj=rep[j],ui=ci^i,uj=cj^j;map<pair<int,int>,pair<H,H>> table;
  for(int y=0;y<N;y++){
   int iy=y^ui,jy=y^uj;long long lo=wt[ci][iy],hi=wt[cj][jy];int t=0;
   while(lo<hi)lo*=2,--t;while(lo>=2*hi)hi*=2,++t;
   int bin=4*t+(4*(lo-hi))/hi,cc=cent[y]==i?1:cent[y]==j?-1:0;
   auto &v=table[{bin,cc}];for(int k=0;k<15;k++){v.first[k]+=hs[ci][iy][k];v.second[k]+=hs[cj][jy][k];}
  }out<<table.size()<<"\n";B+=table.size();for(auto&q:table){for(int v:q.second.first)out<<v<<" ";for(int v:q.second.second)out<<v<<" ";out<<"\n";}
 }
 cerr<<"single types "<<types.size()<<" pair orbits "<<pairs.size()<<" total bins "<<B<<"\n";
}
