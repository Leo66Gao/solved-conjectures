#!/bin/sh
# Run from this directory, with C++17 and unmodified Python 3.10+.
set -eu
"${CXX:-c++}" -O3 -std=c++17 types.cpp -o types
./types
python3 run.py
