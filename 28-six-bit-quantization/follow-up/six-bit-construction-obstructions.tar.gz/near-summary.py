"""Validate the exact near-threshold layer classification from the shifted list."""
from collections import Counter
h=Counter()
for line in open('near-shapes.txt'):
    H,*A=map(int,line.split())
    assert len(set(A))==64 and H>=24480
    s=[sum(1-2*(a>>i&1) for a in A) for i in range(12)]
    assert H==sum(x*x for x in s)
    heavy=sum(a.bit_count()>=3 for a in A)
    if A==list(range(64)):desc='face'
    else:
        assert min(s)>=38 and heavy<=1
        if H>=24576:assert min(s)>=40 and heavy==0 and sum(a.bit_count()==1 for a in A)==12
        desc='radius two' if not heavy else 'one heavy point'
    h[desc]+=1
assert h=={'face':1,'radius two':24,'one heavy point':24}
print(h)
