// Exact necessary conditions for A + C = F_2^12 (unique representations).
// Input on stdin: one missing-pair graph per line, 12 adjacency bitmasks.
// All arithmetic is integral or modulo the prime 1,000,000,007.
#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <iostream>
#include <map>
#include <vector>
using namespace std;
using I=int64_t;
using V=vector<I>;
constexpr int N=4096;
constexpr I p=1000000007;
I inv(I a){I b=1,e=p-2;while(e){if(e&1)b=b*a%p;a=a*a%p;e>>=1;}return b;}
int main(){
 int impossible=0,range_fail=0,graphs=0;array<int,12> G;
 while(cin>>G[0]){
  for(int i=1;i<12;i++)assert(cin>>G[i]);++graphs;
  vector<int>A{0};for(int i=0;i<12;i++){
   assert(!(G[i]>>i&1)); A.push_back(1<<i);
   for(int j=0;j<i;j++){assert((G[i]>>j&1)==(G[j]>>i&1));if(!(G[i]>>j&1))A.push_back(1<<i|1<<j);}
  }assert(A.size()==64);
  array<bool,N>D{};for(int a:A)for(int b:A)D[a^b]=true;
  vector<int>blocks;int done=0;
  for(int i=0;i<12;i++)if(!(done>>i&1)){
   int g=0;for(int j=0;j<12;j++)if(!((G[i]^G[j])&~(1<<i|1<<j)))g|=1<<j;
   assert(!(done&g));blocks.push_back(g);done|=g;
  }
  auto key=[&](int x){int v=0;for(int b:blocks)v=v*(1+__builtin_popcount(b))+__builtin_popcount(b&x);return v;};
  map<int,int> xr;map<int,vector<int>> zo;
  for(int x=0;x<N;x++){
   if(D[x])xr.emplace(key(x),x);
   int w=0;for(int a:A)w+=1-2*__builtin_parity(a&x);
   if(!w)zo[key(x)].push_back(x);
  }
  vector<vector<int>> Z;for(auto &kv:zo)Z.push_back(kv.second);
  int m=xr.size(),n=Z.size();vector<V> M(m,V(n+1));int i=0;
  for(auto kv:xr){
   int x=kv.second;
   for(int t=0;t<n;t++){int h=0;for(int z:Z[t])h+=1-2*__builtin_parity(x&z);M[i][t]=(p+h)%p;}
   M[i][n]=x==0?63:p-1;++i;
  }
  int rank=0;vector<int> piv;
  for(int j=0;j<n;j++){
   int k=rank;while(k<m&&!M[k][j])++k;if(k==m)continue;
   swap(M[k],M[rank]);I a=inv(M[rank][j]);
   for(int q=j;q<=n;q++)M[rank][q]=M[rank][q]*a%p;
   for(int r=0;r<m;r++)if(r!=rank&&M[r][j]){
    I t=M[r][j];for(int q=0;q<=n;q++)M[r][q]=(M[r][q]-(t*M[rank][q])%p+p)%p;
   }piv.push_back(j);++rank;
  }
  bool inconsistent=false;for(int k=rank;k<m;k++)if(M[k][n])inconsistent=true;
  if(inconsistent){++impossible;continue;}
  // A lone modular solution must give an integer orbit sum of squared Walsh
  // coefficients in [0,4096 * orbit size], an interval much smaller than p.
  assert(rank==n);bool bad=false;
  for(int k=0;k<rank;k++){
   I lim=4096*I(Z[piv[k]].size());I w=M[k][n]*lim%p;
   if(w>lim){cout<<"graph "<<graphs-1<<": orbit "<<piv[k]<<", squared-energy residue "<<w<<" exceeds "<<lim<<"\n";bad=true;break;}
  }
  assert(bad);++range_fail;
 }
 cout<<graphs<<" graph types; "<<impossible<<" inconsistent; "<<range_fail<<" impossible by energy range.\n";
 assert(graphs==151&&impossible==150&&range_fail==1);
}
